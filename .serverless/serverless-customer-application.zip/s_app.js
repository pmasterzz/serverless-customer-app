
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'pseigers',
  applicationName: 'customer-app',
  appUid: 'm9Bbg7kn59FH0tMFqh',
  orgUid: '5e11e45b-f5b8-4f45-a6ab-fa5425146009',
  deploymentUid: 'db9883aa-320f-455a-aadc-5170fbe24885',
  serviceName: 'serverless-customer-application',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.0.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-customer-application-dev-app', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}